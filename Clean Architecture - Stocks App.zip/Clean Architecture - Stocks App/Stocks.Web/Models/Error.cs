﻿namespace StockMarketSolution.Models
{
 public class Error
 {
  public string? ErrorMessage { get; set; }
 }
}
